// Create an web server
var datasources = {},
	express = require('express'),
	http = require('http'),
	app = express.createServer(),
	_ = require('underscore'),
	port = 3000,
	host = "localhost",
	dali = require('dali');

// Configure the server's default settings
app.configure(function () {
	app
			.helpers(_.prototype) // Add all of underscore's methods as helpers
			.helpers({
				match: function (col, attr, val) {
					return _(col).find(function (item) {
						return item[attr] == val;
					});
				}
			}) // Add all of underscore's methods as helpers
			.set('view engine', 'dali')
			.set('views', __dirname + '/views')
			.use(express.static(__dirname + '/public'))
			.use(express.errorHandler({
				dumpExceptions: true,
				showStack: true
			}))
			.use(app.router)
});

// Load the JSON datasources
// todo: find a third party module that does that!
function getJSON (url, callback) {
	var options = {
		host: host,
		port: port,
		path: url
	};
	http.get(options, function(res){
	    var data = '';
	    res
				.on('data', function (chunk){
					data += chunk;
				})
				.on('end',function(){
					try {
						var obj = JSON.parse(data);
						callback(obj)
					} catch (e) {
						console.log("FAIL TO PARSE!: ", e.message);
					}
				})
				.on("error", function(e) {
					console.log("FAILED TO LOAD!: ", e.message);
				})
	});
}


function loadDatasources (url, container) {
	getJSON(url, function (data) {
		if (data.datasources) {
			_(data.datasources).each(function (item, key) {
				loadDatasource(key, item.url, container);
			});
		}
	});
}

function loadDatasource (id, url, container) {
	getJSON(url, function (data) {
		container[id] = data;
	});
}


function render(req, res, _options) {
	var viewPath,
		defaults,
		options = {};

	defaults = {
		layout: false
	};
	_(options).extend(defaults, _options);
	options.datasources = datasources;

	viewPath = (options.folder || "") + options.page;
	res.render(viewPath, options);
}

app.get('/sitemap.xml', function(req, res){
	render(req, res, {
		page: "sitemap"
	});
});

app.get('/', function(req, res){
	render(req, res, {
		page: "index"
	});
});

app.get('/:id.html', function(req, res){
	render(req, res, {
		page: "index",
		id: req.params.id
	});
});

app.get('/:page', function(req, res){
	render(req, res, {
		page: req.params.page
	});
});

app.get('/:page/:id.html', function(req, res){
	render(req, res, {
		page: req.params.page,
		id: req.params.id
	});
});

app.get('/:folder/:page/index.html', function(req, res){
	render(req, res, {
		folder: req.params.folder,
		page: "index"
	});
});

app.get('/:folder/:page/:id.html', function(req, res){
	render(req, res, {
		folder: req.params.folder,
		page: req.params.page,
		id: req.params.id
	});
});

// Listen for requests
app.listen(3000);

// Load datasources
loadDatasources("/data/index.json", datasources);
